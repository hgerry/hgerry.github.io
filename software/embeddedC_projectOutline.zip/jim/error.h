/* error.h */

#ifndef ERROR_H
#define	ERROR_H

// Function definitions
extern void error0(void);
extern void error1(void);
extern void flashAll(void);
// Variable definitions

#endif	/* ERROR_H */

